package login_signup;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author RC_Student_lab
 */
import java.io.*;
import java.util.ArrayList;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class UserStorage {
    public static ArrayList<String> usernames = new ArrayList<>();
    public static ArrayList<String> passwords = new ArrayList<>();

    private static final String TXT_FILE = "users.txt";
    private static final String JSON_FILE = "users.json";

    // Load users from file (both TXT and JSON for safety)
    public static void loadUsers() {
        usernames.clear();
        passwords.clear();

        // Load from TXT
        try (BufferedReader reader = new BufferedReader(new FileReader(TXT_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 2) {
                    usernames.add(parts[0]);
                    passwords.add(parts[1]);
                }
            }
        } catch (IOException e) {
            System.out.println("No existing TXT user data found.");
        }

        // Load from JSON
        try (FileReader reader = new FileReader(JSON_FILE)) {
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(reader);
            JSONArray usersArray = (JSONArray) obj;

            for (Object o : usersArray) {
                JSONObject user = (JSONObject) o;
                String username = (String) user.get("username");
                String password = (String) user.get("password");

                // Prevent duplicates if already added from TXT
                if (!usernames.contains(username)) {
                    usernames.add(username);
                    passwords.add(password);
                }
            }
        } catch (Exception e) {
            System.out.println("No existing JSON user data found.");
        }
    }

    // Save new user to both TXT and JSON
    public static void saveUser(String username, String password) {
        usernames.add(username);
        passwords.add(password);

        // Save to TXT
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(TXT_FILE, true))) {
            writer.write(username + "," + password);
            writer.newLine();
        } catch (IOException e) {
            System.out.println("Error saving user to TXT: " + e.getMessage());
        }

        // Save to JSON
        saveToJSON();
    }

    // Write all current users to JSON
    private static void saveToJSON() {
        JSONArray userArray = new JSONArray();

        for (int i = 0; i < usernames.size(); i++) {
            JSONObject userObj = new JSONObject();
            userObj.put("username", usernames.get(i));
            userObj.put("password", passwords.get(i));
            userArray.add(userObj);
        }

        try (FileWriter file = new FileWriter(JSON_FILE)) {
            file.write(userArray.toJSONString());
            file.flush();
        } catch (IOException e) {
            System.out.println("Error saving users to JSON: " + e.getMessage());
        }
    }

    // Check if login details match
    public static boolean checkLogin(String username, String password) {
        for (int i = 0; i < usernames.size(); i++) {
            if (usernames.get(i).equals(username) && passwords.get(i).equals(password)) {
                return true;
            }
        }
        return false;
    }

    public static int getUserCount() {
        return usernames.size();
    }

    public static String getUsername(int index) {
        return usernames.get(index);
    }

    public static String getPassword(int index) {
        return passwords.get(index);
    }
}



    



                    //OpenAl.(2025).ChatGBT[Large language model].
                    //Avalible at : https://chat.openai.com (Accessed 10 April 2025)