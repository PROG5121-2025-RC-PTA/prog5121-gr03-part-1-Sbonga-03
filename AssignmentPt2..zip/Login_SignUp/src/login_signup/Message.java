/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package login_signup;

/**
 *
 * @author RC_Student_lab
 */

import javax.swing.JOptionPane;
import java.util.Random;
import javax.swing.*;
import java.awt.Dimension;
import java.util.ArrayList;
import org.json.JSONObject;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;


public class Message extends javax.swing.JFrame {
    
    
    private String messageID;
    private String recipientNumber;
    private String messageContent;
    private String messageHash;
    private static ArrayList<Message> messages = new ArrayList<>();
    private JTextArea messageDisplayArea;
    
    
     private void storeMessageToJSON(String messageID, String recipient, String messageContent, String messageHash, int messageCount) {
        JSONObject jsonMessage = new JSONObject();
        jsonMessage.put("messageID", messageID);
        jsonMessage.put("recipientNumber", recipient);
        jsonMessage.put("messageContent", messageContent);
        jsonMessage.put("messageHash", messageHash);
        jsonMessage.put("messageCount", messageCount);

        try (FileWriter file = new FileWriter("messages.json", true)) { // 'true' to append
            file.write(jsonMessage.toString());
            file.write(System.lineSeparator());
            file.flush();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving message to file: " + e.getMessage(), "File Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
   
   
    // Method to validate recipient phone number
   public boolean checkRecipientCell(String number) {
    // Clean up any whitespace
    number = number.trim();

    // Validate: must start with +27 followed by 9 digits OR start with 0 followed by 9 digits
    return number.matches("^\\+27\\d{9}$") || number.matches("^0\\d{9}$");
}

// Method to validate message text (not empty and <= 250 chars)
    public boolean checkMessageText(String message) {
    return message != null && !message.trim().isEmpty() && message.length() <= 250;
    }

// Method to generate a 10-digit Message ID
    public String generateMessageID() {
    Random rand = new Random();
    StringBuilder idBuilder = new StringBuilder();
    

    for (int i = 0; i < 10; i++) {
        int digit = rand.nextInt(10);
        idBuilder.append(digit);
    }

    return idBuilder.toString();
}

// Method to create a message hash
public String createMessageHash(String messageID, String messageText, int messageCount) {
    String firstTwoDigits = messageID.substring(0, 2);
    String number = String.valueOf(messageCount);

    String[] words = messageText.trim().split("\\s+");
    String firstWord = words.length > 0 ? words[0] : "";
    String lastWord = words.length > 1 ? words[words.length - 1] : firstWord;

    String wordPart = (firstWord + lastWord).toUpperCase();

    return firstTwoDigits + ":" + number + ":" + wordPart;
}

// Counter for total messages
private static int totalMessages = 0;

public int returnTotalMessages() {
    totalMessages++;
    return totalMessages;
}

public String getMessageID() {
    return messageID;
}

public String getRecipientNumber() {
    return recipientNumber;
}

public String getMessageContent() {
    return messageContent;
}

public String getMessageHash() {
    return messageHash;
} 





    
    public Message() {
        initComponents();
        
        DisplayMessage.setLineWrap(true);
        DisplayMessage.setWrapStyleWord(true);
        
        DisplayMessage.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
    private void updateCount() {
        int remaining = 250 - DisplayMessage.getText().length();
        remaining = Math.max(0, remaining); // Prevent negative numbers
        WordCount.setText("Characters Left: " + remaining);
    }

    @Override
    public void insertUpdate(javax.swing.event.DocumentEvent e) {
        updateCount();
    }

    @Override
    public void removeUpdate(javax.swing.event.DocumentEvent e) {
        updateCount();
    }

    @Override
    public void changedUpdate(javax.swing.event.DocumentEvent e) {
        updateCount(); // Usually not triggered for plain text but safe to include
    }
});
        
        
        
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jCheckBoxMenuItem1 = new javax.swing.JCheckBoxMenuItem();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        RecipientNumber = new javax.swing.JTextField();
        SendMessage = new javax.swing.JButton();
        QuitMessage = new javax.swing.JButton();
        DisregardMessage = new javax.swing.JButton();
        WordCount = new java.awt.Label();
        RecentMessage = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        DisplayMessage = new javax.swing.JTextArea();

        jCheckBoxMenuItem1.setSelected(true);
        jCheckBoxMenuItem1.setText("jCheckBoxMenuItem1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(java.awt.SystemColor.control);

        jPanel2.setBackground(new java.awt.Color(0, 51, 204));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel3.setText("Welcome to QuickChat ");
        jLabel3.setPreferredSize(new java.awt.Dimension(125, 16));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(49, 49, 49)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(55, 55, 55)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 286, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(112, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(jLabel1))
        );

        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("Recipient  Number:");

        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("Message:");

        RecipientNumber.setBackground(new java.awt.Color(204, 204, 204));
        RecipientNumber.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RecipientNumberActionPerformed(evt);
            }
        });

        SendMessage.setBackground(new java.awt.Color(102, 153, 255));
        SendMessage.setForeground(new java.awt.Color(102, 102, 102));
        SendMessage.setText("Send Message");
        SendMessage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SendMessageActionPerformed(evt);
            }
        });

        QuitMessage.setBackground(java.awt.Color.red);
        QuitMessage.setForeground(new java.awt.Color(102, 102, 102));
        QuitMessage.setText("Quit");
        QuitMessage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                QuitMessageActionPerformed(evt);
            }
        });

        DisregardMessage.setBackground(new java.awt.Color(102, 153, 255));
        DisregardMessage.setForeground(new java.awt.Color(102, 102, 102));
        DisregardMessage.setText("Disregard");
        DisregardMessage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DisregardMessageActionPerformed(evt);
            }
        });

        WordCount.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        WordCount.setForeground(new java.awt.Color(51, 51, 51));
        WordCount.setText("Characters left : 250");

        RecentMessage.setBackground(new java.awt.Color(102, 153, 255));
        RecentMessage.setForeground(new java.awt.Color(102, 102, 102));
        RecentMessage.setText("Recent Texts");
        RecentMessage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RecentMessageActionPerformed(evt);
            }
        });

        DisplayMessage.setBackground(new java.awt.Color(204, 204, 204));
        DisplayMessage.setColumns(20);
        DisplayMessage.setRows(5);
        jScrollPane1.setViewportView(DisplayMessage);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(69, 69, 69)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(SendMessage)
                                .addGap(61, 61, 61)
                                .addComponent(RecentMessage))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(RecipientNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 274, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addGap(18, 18, 18)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 321, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(WordCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(DisregardMessage)
                    .addComponent(QuitMessage))
                .addGap(32, 32, 32))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(RecipientNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 157, Short.MAX_VALUE)
                        .addGap(18, 18, 18)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(RecentMessage)
                            .addComponent(DisregardMessage)
                            .addComponent(SendMessage))
                        .addGap(61, 61, 61)
                        .addComponent(WordCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(QuitMessage))
                .addGap(20, 20, 20))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void RecipientNumberActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RecipientNumberActionPerformed
        // TODO add your handling code here:
   String recipientNumber = RecipientNumber.getText();
 // Get number from text field

    if (checkRecipientCell(recipientNumber)) {
        // Valid number - you can now proceed to send the message
        JOptionPane.showMessageDialog(null, "Recipient number is valid.");
    } else {
        // Invalid number - show an error
        JOptionPane.showMessageDialog(null, "Invalid recipient number. It must start with +27 or 0 and be 10 digits long.");
    }    
    }//GEN-LAST:event_RecipientNumberActionPerformed

    private void SendMessageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SendMessageActionPerformed
        // TODO add your handling code here:
    
                                               
    String recipient = RecipientNumber.getText().trim();
    String messageText = DisplayMessage.getText().trim();
    
    
    
    if (!checkRecipientCell(recipient)) {
        JOptionPane.showMessageDialog(this, "Invalid recipient number.\n"
            + "Number must start with 0 (10 digits) or 27 (11 digits).", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    if (!checkMessageText(messageText)) {
        JOptionPane.showMessageDialog(this, "Message must not be empty and must be 250 characters or less.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    messageID = generateMessageID();
    messageContent = messageText;
    recipientNumber = recipient;
    int currentMessageCount = returnTotalMessages();
    messageHash = createMessageHash(messageID, messageContent, currentMessageCount);

    String messageSummary = "        Message Sent Successfully      \n\n"
            + "Recipient Number: " + recipientNumber + "\n"
            + "Message ID: " + messageID + "\n"
            + "Message Hash: " + messageHash + "\n"
            + "Total Messages Sent: " + currentMessageCount +"\n"+"\n"
            + "Message : "+"\n" + messageContent;

    JTextArea textArea = new JTextArea(messageSummary);
    textArea.setLineWrap(true);
    textArea.setWrapStyleWord(true);
    textArea.setEditable(false);
    textArea.setBackground(null);
    textArea.setBorder(null);

JScrollPane scrollPane = new JScrollPane(textArea);
scrollPane.setPreferredSize(new Dimension(350, 200)); // You can adjust size if needed

JOptionPane.showMessageDialog(this, scrollPane, "Message Details", JOptionPane.INFORMATION_MESSAGE);

    storeMessageToJSON(messageID, recipientNumber, messageContent, messageHash, currentMessageCount);


    RecipientNumber.setText("");
    DisplayMessage.setText("");

    
   

    }//GEN-LAST:event_SendMessageActionPerformed

    private void QuitMessageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_QuitMessageActionPerformed
        // TODO add your handling code here:
        
        int confirmation = JOptionPane.showConfirmDialog(
            null,
            "Are you sure you want to quit?",
            "Exit Confirmation",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE
        );
        
        if (confirmation == JOptionPane.YES_OPTION) {
            // Close the current window (chat window) or exit the application
            System.exit(0); // This will completely close the application
            
        }
    
    }//GEN-LAST:event_QuitMessageActionPerformed

    private void RecentMessageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RecentMessageActionPerformed
        // TODO add your handling code here:
                                                 
    if (messages.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Coming soon!");
    } else {
        StringBuilder messageList = new StringBuilder();
        for (Message m : messages) {
            messageList.append("Message ID: ").append(m.getMessageID()).append("\n");
            messageList.append("Recipient: ").append(m.getRecipientNumber()).append("\n");
            messageList.append("Message: ").append(m.getMessageContent()).append("\n");
            messageList.append("Hash: ").append(m.getMessageHash()).append("\n");
            messageList.append("---------\n");
        }

        JTextArea textArea = new JTextArea(messageList.toString());
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(400, 300));
        JOptionPane.showMessageDialog(null, scrollPane, "Recent Messages", JOptionPane.INFORMATION_MESSAGE);
    }

    
     
    }//GEN-LAST:event_RecentMessageActionPerformed

    private void DisregardMessageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DisregardMessageActionPerformed
        // TODO add your handling code here:
        RecipientNumber.setText("");
    DisplayMessage.setText("");
    
    JOptionPane.showMessageDialog(this, "Message cleared.", "Disregard", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_DisregardMessageActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Message().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea DisplayMessage;
    private javax.swing.JButton DisregardMessage;
    private javax.swing.JButton QuitMessage;
    private javax.swing.JButton RecentMessage;
    private javax.swing.JTextField RecipientNumber;
    private javax.swing.JButton SendMessage;
    private java.awt.Label WordCount;
    private javax.swing.JCheckBoxMenuItem jCheckBoxMenuItem1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}






 //OpenAl.(2025).ChatGBT[Large language model].
                    //Avalible at : https://chat.openai.com (Accessed 10 April 2025)